# Classic Arcade Game Clone Project

## Table of Contents

- [Instructions](#instructions)


## Instructions
To play the game you have to use the arrow keys to move up, down, left or right.
You must avoid the animies and eat (match) all sweets
